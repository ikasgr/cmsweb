<?php
header ('Location:https://datagoe.com/');
?>